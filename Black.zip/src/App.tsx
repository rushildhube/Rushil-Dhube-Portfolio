/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useInView } from 'motion/react';
import Lenis from 'lenis';
import { 
  Github, 
  Linkedin, 
  Mail,
  ExternalLink,
  ArrowUpRight
} from 'lucide-react';

// --- Custom Icons ---
const FiverrLogo = ({ size = 20, className = "" }: { size?: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 512 512" fill="currentColor" className={className}>
    <path d="M112.5 264.9C102.3 264.9 94 273.2 94 283.5 94 293.7 102.3 302 112.5 302C122.7 302 131 293.7 131 283.5 131 273.2 122.7 264.9 112.5 264.9ZM169.5 241h-26v-19c0-9.8 4.2-12.7 12.8-12.7 6.1 0 12.1 2.8 17.5 7.8l17.7-27.4c-9.5-9.3-24.1-15.7-41.2-15.7-36.8 0-48.8 20.8-48.8 49.3V241H81v25.2h19.5v72.5h33.8v-72.5h38.2L169.5 241zM286 211.5l14-37.5c-9.5-9.3-24.1-15.7-41.2-15.7-36.8 0-48.8 20.8-48.8 49.3V241H189v25.2h20.5v72.5h33.8v-72.5h38.2l-3-25.2h-35.2v-19c0-9.8 4.2-12.7 12.8-12.7 6.1 0 12.1 2.8 17.5 7.8L286 211.5zM431 241h-78.5c2 21.3 15.5 28.5 31.5 28.5 7.5 0 14.8-1.5 21-4.5l8.5 24.8c-10.5 6-22 9.2-36 9.2-39.2 0-58.8-21.5-58.8-54.8 0-35.2 24.2-56.5 56.5-56.5s53.2 21.8 53.2 56 0 0 0 0 2.5 7.2 2.5 7.2L431 241zM380.5 198.5c-11.8 0-21.8 6.5-26.5 20h53.5C407.5 205 396.5 198.5 380.5 198.5zM461.5 241h-26.5l3 25.2h23.5L461.5 241zM512 241l-14-37.5C488.5 194.2 473.9 187.8 456.8 187.8c-36.8 0-48.8 20.8-48.8 49.3V241h-20.5v25.2h20.5v72.5h33.8v-72.5H480L512 241z" />
  </svg>
);

// --- Motion Config ---
const CUBIC = [0.76, 0, 0.24, 1]; // Premium smooth easing

// --- Mock Data ---
interface Project {
  id: string; title: string; category: string; description: string; tech: string[]; image: string; github: string; live: string;
}

const PROJECTS: Project[] = [
  {
    id: '1', title: 'DENTAL DISEASE CLASSIFIER', category: 'Medical Vision',
    description: 'Engineered production-grade web system classifying 6 dental conditions utilizing Vision Transformer (ViT-B/16) architecture with PyTorch, fine-tuned on 3,000+ images.',
    tech: ['ViT-B/16', 'PyTorch', 'FastAPI', 'MongoDB'],
    image: 'https://images.unsplash.com/photo-1606206591513-adb628eefd20?q=80&w=2000&auto=format&fit=crop', // Replaced with unsplash
    github: 'https://github.com/rushildhube', live: '#'
  },
  {
    id: '2', title: 'SAFE SURF AI', category: 'Security Infrastructure',
    description: 'Real-time URL threat detection Chrome extension integrating VirusTotal API with a custom highly optimized Django/FastAPI backend cache layer.',
    tech: ['Django', 'FastAPI', 'Redis', 'Selenium'],
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=2000&auto=format&fit=crop',
    github: 'https://github.com/rushildhube', live: '#'
  },
  {
    id: '6', title: 'SNIPER THINK', category: 'Autonomous Pipelines',
    description: 'End-to-end social media automation and conversational pipelines architected using Make.com, Meta Graph API, and advanced GenAI integrations.',
    tech: ['Make.com', 'Meta API', 'Gemini', 'Google Veo'],
    image: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2000&auto=format&fit=crop',
    github: 'https://github.com/rushildhube', live: '#'
  },
  {
    id: '8', title: 'WELLBE REVIVE 360', category: 'NLP / RAG Systems',
    description: 'End-to-end nutrition chatbot with stringent safety guardrails. Built on a massive Qdrant vector store and evaluated via TruLens.',
    tech: ['RAG', 'LLMs', 'Qdrant', 'TruLens'],
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?q=80&w=2000&auto=format&fit=crop',
    github: 'https://github.com/rushildhube', live: '#'
  }
];

const EXPERTISE = [
  { id: 'vision', title: 'Computer Vision', desc: 'High-precision deep learning implementation for medical imaging and complex visual recognition challenges.', metrics: '92.4% Diagnostic Accuracy' },
  { id: 'neuro', title: 'NLP & RAG', desc: 'Specialist in building neural conversational systems and high-precision evaluation matrices for AI safety.', metrics: 'Vector Search & LLM Orchestration' },
  { id: 'forge', title: 'Generative Automation', desc: 'Engineering sophisticated automation architectures that leverage GenAI to streamline complex business operations.', metrics: 'End-to-end Orchestration' },
  { id: 'core', title: 'Backend Systems', desc: 'Architecting robust, mission-critical infrastructure and high-performance backend systems with a focus on code scalability and resilience.', metrics: 'High-Throughput APIs' }
];

// --- Utility Components ---

const SmoothScroll: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.5,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)), // Easing function for agency feel
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1.2,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);

    return () => lenis.destroy();
  }, []);

  return <>{children}</>;
};

const CustomCursor: React.FC = () => {
  const [mousePosition, setMousePosition] = useState({ x: -100, y: -100 });
  const [isHovering, setIsHovering] = useState(false);

  useEffect(() => {
    const updateMousePosition = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'BUTTON' || target.tagName === 'A' || target.closest('button') || target.closest('a')) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', updateMousePosition);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', updateMousePosition);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 w-8 h-8 rounded-full pointer-events-none z-[9999] mix-blend-difference bg-white hidden lg:flex items-center justify-center origin-center"
      animate={{
        x: mousePosition.x - 16,
        y: mousePosition.y - 16,
        scale: isHovering ? 2 : 0.5,
        opacity: 1
      }}
      transition={{ type: 'spring', stiffness: 300, damping: 28, mass: 0.5 }}
    />
  );
};

const MagneticButton: React.FC<{ children: React.ReactNode, className?: string, onClick?: () => void }> = ({ children, className = "", onClick }) => {
  const ref = useRef<HTMLButtonElement>(null);
  const [position, setPosition] = useState({ x: 0, y: 0 });

  const handleMouse = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!ref.current) return;
    const { clientX, clientY } = e;
    const { height, width, left, top } = ref.current.getBoundingClientRect();
    const middleX = clientX - (left + width / 2);
    const middleY = clientY - (top + height / 2);
    setPosition({ x: middleX * 0.2, y: middleY * 0.2 });
  };

  const reset = () => {
    setPosition({ x: 0, y: 0 });
  };

  return (
    <motion.button
      ref={ref}
      onClick={onClick}
      onMouseMove={handleMouse}
      onMouseLeave={reset}
      animate={{ x: position.x, y: position.y }}
      transition={{ type: "spring", stiffness: 150, damping: 15, mass: 0.1 }}
      className={className}
    >
      {children}
    </motion.button>
  );
};

// --- Page Sections ---

const Preloader: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 800);
          return 100;
        }
        return p + Math.floor(Math.random() * 8) + 2;
      });
    }, 40);
    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div 
      className="fixed inset-0 z-[1000] bg-agency-bg flex flex-col justify-between p-8 md:p-16"
      initial={{ y: 0 }}
      exit={{ y: "-100%", transition: { duration: 1.2, ease: CUBIC } }}
    >
      <div className="flex justify-between w-full overflow-hidden">
        <motion.span 
          initial={{ y: 50, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }} 
          transition={{ duration: 1, ease: CUBIC }}
          className="font-mono text-sm tracking-widest uppercase text-white/50"
        >
          Rushil Dhube
        </motion.span>
        <motion.span 
          initial={{ y: 50, opacity: 0 }} 
          animate={{ y: 0, opacity: 1 }} 
          transition={{ duration: 1, ease: CUBIC, delay: 0.1 }}
          className="font-mono text-sm tracking-widest uppercase text-white/50"
        >
          Portfolio 26
        </motion.span>
      </div>
      
      <div className="font-display font-medium text-[15vw] leading-none text-white tracking-tighter flex items-end">
        {Math.min(progress, 100)}%
      </div>
    </motion.div>
  );
};

const Navbar: React.FC = () => {
  const [hidden, setHidden] = useState(false);
  const { scrollY } = useScroll();
  const [lastY, setLastY] = useState(0);

  useEffect(() => {
    return scrollY.on("change", (latest) => {
      if (latest < 100) setHidden(false);
      else if (latest > lastY) setHidden(true);
      else setHidden(false);
      setLastY(latest);
    });
  }, [scrollY, lastY]);

  return (
    <motion.nav
      variants={{
        visible: { y: 0, opacity: 1 },
        hidden: { y: -50, opacity: 0 }
      }}
      animate={hidden ? "hidden" : "visible"}
      transition={{ duration: 0.6, ease: CUBIC }}
      className="fixed top-0 left-0 w-full z-50 p-6 md:p-10 flex justify-between items-center mix-blend-difference"
    >
      <a href="#" className="font-display font-bold text-xl tracking-tight text-white select-none">
        RD<span className="opacity-50">©</span>
      </a>
      <MagneticButton className="font-sans text-sm hover:opacity-70 transition-opacity select-none tracking-wide text-white uppercase">
        <a href="mailto:rushildhube1305@gmail.com">Contact</a>
      </MagneticButton>
    </motion.nav>
  );
};

const RevealText: React.FC<{ text: string, className?: string, delay?: number, once?: boolean }> = ({ text, className = "", delay = 0, once = true }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once, margin: "-10%" });
  const words = text.split(" ");

  return (
    <h1 ref={ref} className={`flex flex-wrap ${className}`}>
      {words.map((word, i) => (
        <span key={i} className="overflow-hidden inline-flex mr-[0.25em]">
          <motion.span
            initial={{ y: "100%" }}
            animate={isInView ? { y: 0 } : { y: "100%" }}
            transition={{ duration: 1.2, ease: CUBIC, delay: delay + (i * 0.04) }}
            className="inline-block transform-gpu origin-bottom-left"
            style={{ paddingBottom: '0.1em' }}
          >
            {word === " " ? "\u00A0" : word}
          </motion.span>
        </span>
      ))}
    </h1>
  );
};


const Hero: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);

  return (
    <section ref={ref} className="h-[100svh] w-full flex flex-col justify-end p-6 md:p-12 lg:p-24 relative overflow-hidden">
      <motion.div style={{ y, opacity }} className="w-full relative z-10 flex flex-col gap-4">
        <p className="font-mono text-sm tracking-widest uppercase text-white/50 overflow-hidden">
          <motion.span 
            initial={{ y: "100%" }} animate={{ y: 0 }} transition={{ duration: 1, delay: 1.5, ease: CUBIC }}
            className="block"
          >
            AI & Machine Learning Architect
          </motion.span>
        </p>
        <RevealText 
          text="RUSHIL DHUBE" 
          className="text-[clamp(4rem,15vw,12rem)] font-display font-medium tracking-tighter leading-[0.85] text-white" 
          delay={1.2} 
        />
      </motion.div>
      <motion.div 
        className="absolute bottom-12 right-12 md:right-24 h-16 w-16 rounded-full border border-white/20 flex flex-col items-center justify-center text-white/50"
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        transition={{ delay: 2.5, duration: 1 }}
      >
        <span className="font-mono text-[10px] uppercase mb-1">Scroll</span>
        <div className="w-px h-4 bg-white/50 overflow-hidden relative">
          <motion.div 
            animate={{ y: [-16, 16] }} 
            transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
            className="absolute inset-0 bg-white"
          />
        </div>
      </motion.div>
    </section>
  );
};

const About: React.FC = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-20%" });

  return (
    <section className="py-32 px-6 md:px-12 lg:px-24 bg-agency-bg-alt relative z-20">
      <div className="max-w-4xl ml-auto">
        <p ref={ref} className="text-[clamp(1.5rem,3.5vw,3rem)] font-sans font-light leading-tight tracking-tight text-white/90">
          I build <span className="text-white italic font-display pr-1">intelligent systems</span> that bridge the gap between complex neural networks and scalable production architectures. Specialize in Healthcare AI, high-performance backends, and sophisticated GenAI integrations.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mt-32">
          {['B.E. AI/ML Engineering', 'Top 5% NPTEL Python', 'Multiple Clinical Deployments'].map((text, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0, y: 30 }}
               animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
               transition={{ duration: 0.8, delay: 0.2 + (i * 0.1), ease: CUBIC }}
               className="border-t border-white/10 pt-6"
             >
               <h4 className="font-mono text-xs tracking-widest uppercase text-white/40 mb-2">0{i+1}</h4>
               <p className="font-sans text-lg text-white/80">{text}</p>
             </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Expertise: React.FC = () => {
  return (
    <section className="py-32 px-6 md:px-12 lg:px-24">
      <div className="mb-20">
        <RevealText text="Core Expertise" className="text-5xl md:text-7xl font-display font-medium text-white tracking-tighter" />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10">
        {EXPERTISE.map((exp, i) => (
          <div key={i} className="bg-agency-bg p-8 md:p-16 group hover:bg-white/[0.02] transition-colors duration-500">
            <div className="font-mono text-xs tracking-widest text-white/30 uppercase mb-8">0{i+1}</div>
            <h3 className="text-3xl font-display font-medium text-white mb-6 tracking-tight group-hover:pl-2 transition-all duration-500">{exp.title}</h3>
            <p className="text-white/50 mb-12 font-sans font-light leading-relaxed max-w-sm">{exp.desc}</p>
            <div className="flex items-center gap-4 text-xs font-mono uppercase text-white/40 tracking-widest">
              <span className="w-1.5 h-1.5 bg-white/40 rounded-full group-hover:scale-150 group-hover:bg-white transition-all"></span>
              {exp.metrics}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

const WorkGallery: React.FC = () => {
  const targetRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: targetRef });
  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-66.66%"]);

  return (
    <section ref={targetRef} className="relative h-[300vh] bg-agency-bg-alt">
      <div className="sticky top-0 h-screen flex flex-col justify-center overflow-hidden">
        <div className="absolute top-12 md:top-24 left-6 md:left-24 z-20">
          <RevealText text="Selected Works" className="text-4xl md:text-6xl font-display font-medium text-white tracking-tighter" />
        </div>
        
        <motion.div style={{ x }} className="flex gap-12 px-6 md:px-24 mt-24">
          {PROJECTS.map((project, idx) => (
            <div key={idx} className="w-[85vw] md:w-[60vw] lg:w-[45vw] flex-shrink-0 group">
              <div className="w-full aspect-[4/3] overflow-hidden bg-white/5 relative mb-8 rounded-sm">
                <motion.img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-full object-cover grayscale transition-all duration-700 ease-[cubic-bezier(0.76,0,0.24,1)] group-hover:scale-105 group-hover:grayscale-0"
                />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-700"></div>
                <div className="absolute top-0 right-0 p-6 opacity-0 group-hover:opacity-100 transition-opacity duration-500 transform translate-x-4 group-hover:translate-x-0">
                  <a href={project.github} className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-black hover:scale-110 transition-transform">
                    <ArrowUpRight strokeWidth={1.5} size={24} />
                  </a>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                <div>
                  <div className="font-mono text-[10px] tracking-widest uppercase text-white/40 mb-3">{project.category}</div>
                  <h3 className="text-3xl font-display font-medium tracking-tight text-white mb-4">{project.title}</h3>
                  <div className="flex flex-wrap gap-2">
                    {project.tech.map((t, i) => (
                      <span key={i} className="px-3 py-1 text-[10px] font-mono tracking-widest border border-white/10 text-white/60 rounded-full">{t}</span>
                    ))}
                  </div>
                </div>
                <p className="max-w-xs text-sm font-sans font-light text-white/50 leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="pt-40 pb-12 px-6 md:px-12 lg:px-24 bg-agency-bg relative overflow-hidden">
      <div className="max-w-7xl mx-auto flex flex-col gap-32">
        <div className="flex flex-col items-start gap-12">
          <p className="font-mono text-sm tracking-widest uppercase text-white/40">Ready to build?</p>
          <a href="mailto:rushildhube1305@gmail.com" className="text-[clamp(3rem,10vw,8rem)] leading-none font-display font-medium tracking-tighter text-white hover:italic transition-all duration-300">
             Let's Talk.
          </a>
        </div>
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12 pt-12 border-t border-white/10">
          <div className="flex gap-8">
            <a href="https://github.com/rushildhube" target="_blank" className="font-mono text-xs tracking-widest uppercase text-white/50 hover:text-white transition-colors underline-slide">GitHub</a>
            <a href="https://linkedin.com/in/rushildhube" target="_blank" className="font-mono text-xs tracking-widest uppercase text-white/50 hover:text-white transition-colors underline-slide">LinkedIn</a>
            <a href="https://www.fiverr.com/rushildhube" target="_blank" className="font-mono text-xs tracking-widest uppercase text-white/50 hover:text-white transition-colors underline-slide">Fiverr</a>
          </div>
          <div className="font-mono text-xs tracking-widest text-white/30 uppercase">
             © 2026 // Rushil Dhube
          </div>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      <CustomCursor />
      <AnimatePresence mode="wait">
        {loading && <Preloader key="preloader" onComplete={() => setLoading(false)} />}
      </AnimatePresence>
      <SmoothScroll>
        <AnimatePresence>
          {!loading && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1.2, ease: CUBIC }}
              className="w-full relative z-10"
            >
              <Navbar />
              <Hero />
              <About />
              <Expertise />
              <WorkGallery />
              <Footer />
            </motion.div>
          )}
        </AnimatePresence>
      </SmoothScroll>
    </>
  );
}
